
const imagenes = document.getElementById("contImagenes");

imagenes.addEventListener("click", (event)=>{

    const imagenClickeada = event.target;

    console.log(imagenClickeada);

});