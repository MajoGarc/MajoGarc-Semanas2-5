<?php

function encriptar($info)
{
    return "'$info'Encriptada";
}
