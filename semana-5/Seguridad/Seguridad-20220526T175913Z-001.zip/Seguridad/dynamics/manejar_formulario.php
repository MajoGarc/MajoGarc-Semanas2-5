<?php

require_once "seguridad.php";

$usuario = $_POST["usuario"];
$info = $_POST["input-chido"];

session_start();

$_SESSION['usuario'] = $usuario;

echo "Tú eres: " . $_SESSION['usuario'];
echo "<br>";
echo encriptar($info);
echo "<br>";
