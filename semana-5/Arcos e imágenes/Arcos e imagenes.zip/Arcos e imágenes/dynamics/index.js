const canvas = document.getElementById("mi_canvas");
ctx = canvas.getContext("2d");

// Dibujando arcos y circulos.
let angInicio = 180 * Math.PI / 180;
let angFinal = 0 * Math.PI / 180;

// Arco
ctx.beginPath();
ctx.arc(250, 250, 100, angInicio, angFinal);
ctx.lineWidth = 10;
ctx.stroke();
ctx.closePath();

// Círculo
// ctx.beginPath();
// ctx.arc(250, 250, 50, 0, Math.PI * 2);
// ctx.fill();
// ctx.closePath();

// Líneas Guía
// ctx.beginPath();
// ctx.strokeStyle = "#c4c4c4";
// ctx.moveTo(100, 100);
// ctx.lineTo(100, 300);
// ctx.lineTo(300, 300);
// ctx.stroke();
// ctx.closePath();

// Esquina redondeada
// ctx.beginPath();
// ctx.strokeStyle = "#000000";
// ctx.moveTo(100, 100);
// ctx.arcTo(100, 300, 300, 300, 200);
// ctx.stroke();
// ctx.closePath();


